"""Manager classes for resource and operation management"""

from .backend_manager import BackendManager

__all__ = [
    'BackendManager'
]